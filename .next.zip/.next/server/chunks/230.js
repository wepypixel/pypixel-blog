exports.id = 230;
exports.ids = [230];
exports.modules = {

/***/ 5230:
/***/ ((module) => {

// Exports
module.exports = {
	"posts-list-container": "BlogPostList_posts-list-container__eN50t",
	"posts-grid-container": "BlogPostList_posts-grid-container__9Phgb",
	"post-grid-item-img": "BlogPostList_post-grid-item-img__KNgje",
	"post-date": "BlogPostList_post-date__VYxS6",
	"grid-post-date-div": "BlogPostList_grid-post-date-div__Ikw4C",
	"grid-card-post-title": "BlogPostList_grid-card-post-title__I7zHF",
	"blog-post-hero-link": "BlogPostList_blog-post-hero-link__3ZxJA",
	"prev-next-btn-div": "BlogPostList_prev-next-btn-div__XI72v",
	"previous-btn": "BlogPostList_previous-btn__XjNJ5",
	"next-btn": "BlogPostList_next-btn__ilviB"
};


/***/ })

};
;