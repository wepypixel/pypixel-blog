exports.id = 901;
exports.ids = [901];
exports.modules = {

/***/ 4901:
/***/ ((module) => {

// Exports
module.exports = {
	"category-posts-heading": "CategoryPosts_category-posts-heading__8G0RN",
	"posts-list-container": "CategoryPosts_posts-list-container__X0RCN",
	"posts-grid-container": "CategoryPosts_posts-grid-container__E2FBi",
	"post-grid-item-img": "CategoryPosts_post-grid-item-img__owNPG",
	"post-date": "CategoryPosts_post-date__x8oAT",
	"grid-post-date-div": "CategoryPosts_grid-post-date-div__v_FyH",
	"grid-card-post-title": "CategoryPosts_grid-card-post-title__MVmLq",
	"blog-post-hero-link": "CategoryPosts_blog-post-hero-link__FwfIo",
	"prev-next-btn-div": "CategoryPosts_prev-next-btn-div__TZ7Dy",
	"previous-btn": "CategoryPosts_previous-btn__qW_lh",
	"next-btn": "CategoryPosts_next-btn__39CDb"
};


/***/ })

};
;